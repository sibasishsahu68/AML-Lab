from flask import Flask, render_template, request

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import os

app = Flask(__name__)

STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
os.makedirs(STATIC_DIR, exist_ok=True)
GRAPH_PATH = os.path.join(STATIC_DIR, "graph.png")


def compute_multiple_regression(X, y):
    """Runs Multiple Linear Regression using Least Squares Method.
    X: numpy array of shape (n, m) where n is number of samples, m is number of features
    y: numpy array of shape (n,) with target values
    Returns coefficients and error metrics."""
    n = len(y)
    
    # Add intercept term (column of 1s)
    X_with_intercept = np.column_stack([np.ones(n), X])
    
    # Least Squares solution: β = (X^T X)^(-1) X^T y
    try:
        coefficients = np.linalg.lstsq(X_with_intercept, y, rcond=None)[0]
    except np.linalg.LinAlgError:
        raise Exception("Matrix is singular. Check your input data.")
    
    intercept = coefficients[0]
    slopes = coefficients[1:]
    
    # Predictions
    y_pred = X_with_intercept @ coefficients
    residuals = y - y_pred
    
    # Error metrics
    mae = np.mean(np.abs(residuals))
    mse = np.mean(residuals ** 2)
    rmse = np.sqrt(mse)
    
    ss_res = np.sum(residuals ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    r2 = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0
    
    # Adjusted R²
    num_features = X.shape[1]
    adj_r2 = 1 - (1 - r2) * (n - 1) / (n - num_features - 1) if (n - num_features - 1) > 0 else 0
    
    return {
        "n": n,
        "num_features": num_features,
        "intercept": intercept,
        "slopes": slopes,
        "mae": mae,
        "mse": mse,
        "rmse": rmse,
        "r2": r2,
        "adj_r2": adj_r2,
        "residuals": residuals,
        "y_pred": y_pred
    }


@app.route("/", methods=["GET", "POST"])
def home():
    result = None
    error = None
    show_graph = False
    x_inputs = []
    y_input = ""

    if request.method == "POST":
        action = request.form.get("action", "calculate")
        y_input = request.form.get("y_values", "")
        
        # Collect all X inputs (x1, x2, x3, etc.)
        x_inputs = []
        i = 1
        while f"x{i}_values" in request.form:
            x_inputs.append(request.form.get(f"x{i}_values", ""))
            i += 1

        if action == "reset":
            result = None
            error = None
            show_graph = False
            x_inputs = []
            y_input = ""
            if os.path.exists(GRAPH_PATH):
                os.remove(GRAPH_PATH)
            return render_template("index.html", result=result, error=error, show_graph=show_graph,
                                    x_inputs=x_inputs, y_input=y_input)

        try:
            if not x_inputs or not any(x_inputs):
                raise Exception("Enter at least one X variable.")
            if not y_input:
                raise Exception("Enter Y values.")
            
            # Parse Y values
            y = np.array([float(v) for v in y_input.split(",")])
            
            # Parse X values (multiple features)
            X_list = []
            for x_str in x_inputs:
                if x_str.strip():
                    x = np.array([float(v) for v in x_str.split(",")])
                    X_list.append(x)
            
            if not X_list:
                raise Exception("Enter at least one X variable.")
            
            # Stack X values into matrix
            X = np.column_stack(X_list)
            
            # Validate dimensions
            if X.shape[0] != len(y):
                raise Exception("All X and Y must have the same number of values.")
            if X.shape[0] < 2:
                raise Exception("Enter at least two data points.")
            
            r = compute_multiple_regression(X, y)

            if action == "visualize":
                # Visualization for multiple regression
                num_features = r["num_features"]
                
                if num_features == 1:
                    # 2D plot for single feature
                    plt.figure(figsize=(12, 5))
                    
                    # Left subplot: regression fit
                    plt.subplot(1, 2, 1)
                    x_vals = X[:, 0]
                    plt.scatter(x_vals, y, color="#4361ee", s=70, label="Data Points", edgecolor="white")
                    x_line = np.linspace(x_vals.min(), x_vals.max(), 100)
                    y_line = r["intercept"] + r["slopes"][0] * x_line
                    plt.plot(x_line, y_line, color="#f72585", linewidth=2.5, label="Regression Line")
                    
                    plt.xlabel("X₁")
                    plt.ylabel("Y")
                    plt.title("Multiple Linear Regression Fit (1 Feature)")
                    plt.grid(alpha=0.3)
                    plt.legend(loc="lower right")
                    
                elif num_features == 2:
                    # 3D plot for two features
                    from mpl_toolkits.mplot3d import Axes3D
                    
                    fig = plt.figure(figsize=(12, 5))
                    
                    # Left subplot: 3D scatter and plane
                    ax1 = fig.add_subplot(121, projection='3d')
                    x1 = X[:, 0]
                    x2 = X[:, 1]
                    ax1.scatter(x1, x2, y, color="#4361ee", s=70, label="Data Points", edgecolor="white")
                    
                    # Create mesh for regression plane
                    x1_min, x1_max = x1.min(), x1.max()
                    x2_min, x2_max = x2.min(), x2.max()
                    x1_mesh = np.linspace(x1_min, x1_max, 10)
                    x2_mesh = np.linspace(x2_min, x2_max, 10)
                    x1_grid, x2_grid = np.meshgrid(x1_mesh, x2_mesh)
                    y_grid = r["intercept"] + r["slopes"][0] * x1_grid + r["slopes"][1] * x2_grid
                    
                    ax1.plot_surface(x1_grid, x2_grid, y_grid, alpha=0.3, color="#f72585")
                    ax1.set_xlabel("X₁")
                    ax1.set_ylabel("X₂")
                    ax1.set_zlabel("Y")
                    ax1.set_title("Multiple Linear Regression (2 Features)")
                    
                else:
                    # For 3+ features, just show scatter plot of predicted vs actual
                    fig = plt.figure(figsize=(12, 5))
                    plt.subplot(1, 2, 1)
                    plt.scatter(y, r["y_pred"], color="#4361ee", s=70, label="Predictions", edgecolor="white")
                    max_val = max(y.max(), r["y_pred"].max())
                    min_val = min(y.min(), r["y_pred"].min())
                    plt.plot([min_val, max_val], [min_val, max_val], color="#f72585", linewidth=2.5, label="Perfect Fit")
                    plt.xlabel("Actual Y")
                    plt.ylabel("Predicted Y")
                    plt.title(f"Multiple Linear Regression ({num_features} Features)")
                    plt.grid(alpha=0.3)
                    plt.legend()
                
                # Right subplot: metrics scatter plot
                plt.subplot(1, 2, 2)
                metrics = ["MAE", "MSE", "RMSE", "R²", "Adj R²"]
                values = [r["mae"], r["mse"], r["rmse"], r["r2"], r["adj_r2"]]
                colors = ["#ffb703", "#fb8500", "#219ebc", "#023047", "#8ecae6"]
                
                plt.scatter(metrics, values, s=120, c=colors, edgecolor="black")
                for i, v in enumerate(values):
                    plt.text(metrics[i], v + 0.01, f"{v:.4f}", ha="center", fontsize=9)
                
                plt.title("Error Metrics Scatter Plot")
                plt.ylabel("Value")
                plt.grid(alpha=0.3)
                
                plt.tight_layout()
                plt.savefig(GRAPH_PATH, dpi=110)
                plt.close()
                
                show_graph = True

            else:
                # Build equation string
                eq_parts = [f"{round(r['intercept'], 4)}"]
                for i, slope in enumerate(r["slopes"]):
                    var_name = f"x{i+1}"
                    sign = "+" if slope >= 0 else ""
                    eq_parts.append(f"{sign} {round(slope, 4)}{var_name}")
                
                equation = "y = " + " ".join(eq_parts)
                
                # Build summary
                summary = [
                    ("Num Features", r["num_features"]),
                    ("Num Samples", r["n"]),
                    ("Intercept (b₀)", round(r["intercept"], 4)),
                ]
                for i, slope in enumerate(r["slopes"]):
                    summary.append((f"Slope (b{i+1})", round(slope, 4)))
                
                result = {
                    "equation": equation,
                    "summary": summary,
                    "accuracy": [
                        ("MAE", round(r["mae"], 4)),
                        ("MSE", round(r["mse"], 4)),
                        ("RMSE", round(r["rmse"], 4)),
                        ("R²", round(r["r2"], 4)),
                        ("Adj R²", round(r["adj_r2"], 4)),
                    ],
                }

        except Exception as e:
            error = str(e)

    return render_template("index.html", result=result, error=error, show_graph=show_graph,
                            x_inputs=x_inputs, y_input=y_input)


if __name__ == "__main__":
   app.run(debug=True, port=5080)
